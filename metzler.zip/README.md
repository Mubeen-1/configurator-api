# Metzler Configurator API

## First run

```
git clone ...
cd ...
npm i
make up_local
make reset
```

