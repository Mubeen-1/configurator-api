export enum DocumentationTag {
  CONFIG = 'config',
}
