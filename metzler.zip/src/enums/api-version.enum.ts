export enum ApiVersion {
  V1 = '1',
}
