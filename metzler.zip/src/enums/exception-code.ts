export enum ExceptionCode {
  INVARIANT_VIOLATION = 1000,
}
