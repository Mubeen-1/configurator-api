export enum Env {
  DEV = 'dev',
  PROD = 'prod',
}
