export enum ConfigStatus {
  CREATED = 'created',
  ORDERED = 'ordered',
}
