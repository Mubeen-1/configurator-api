export enum TransactionIsolationLevel {
  SERIALIZABLE = 'serializable',
  BASE = 'base',
}
