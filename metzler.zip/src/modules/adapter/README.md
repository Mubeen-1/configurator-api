# Adapter module

The adapter module provides service and repositories registration in nestjs DI-system.
