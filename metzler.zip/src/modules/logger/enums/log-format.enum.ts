export enum LogFormat {
  JSON = 'json',
  CONSOLE = 'console',
}
