export enum OrderDirection {
  ASC = 'ASC',
  DESC = 'DESC',
}
