export enum PostgresExceptionCode {
  UNIQUE_VIOLATION = '23505',
}
