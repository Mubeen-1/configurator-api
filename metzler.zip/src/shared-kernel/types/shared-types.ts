export type UuidString = string;
export type UrlLike = string;
